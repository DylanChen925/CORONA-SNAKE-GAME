-- config.lua

application =
{
	content =
	{
		width = 540,
		height = 960,
		scale = "zoomEven" -- zoom to fill screen, possibly cropping edges
	},
}