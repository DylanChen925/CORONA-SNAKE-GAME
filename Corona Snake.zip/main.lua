math.randomseed( os.time() )
local widget = require("widget")
local Size  = 25
local Delay = 25
local Speed = 7.5
local su = 0
local scoreCount = 0
local scoreCountold = 0
local xdir = 0
local ydir = 0
local hit = audio.loadStream("sound/hit.wav")
local speedup = audio.loadStream("sound/speedup.wav")
local eat = audio.loadSound("sound/eat.wav")
audio.setVolume( 0.3 )

_W = display.contentWidth
_H = display.contentHeight

--遊戲邊界--
local Top   = display.newRect(_W/2,       3, _W,      5)
local Floor = display.newRect(_W/2,  _H-150, _W,      5)
local Lwall = display.newRect(   3, _H/2-75,  5, _H-150)
local Rwall = display.newRect(_W-3, _H/2-75,  5, _H-150)
--/////--

--設置蛇--
local snake = {}
snake[1] = display.newRect(_W/2, _H/2, Size, Size)
snake[1]:setFillColor(0, 1, 0)
--/////--

--設置食物--
local food = display.newRect(math.random(50, _W-50), math.random(20, _H-180), Size, Size)
food:setFillColor(1, 1, 0)
--/////--

--設置記分板--
local scoretext = display.newText("SCORE", 75, _H-125, "font/munro.ttf", 20)
local score = display.newText(scoreCount, 75, _H-100, "font/munro.ttf", 40)
score:setTextColor(1, 1, 1)

local scoreoldtext = display.newText("HIGHEST SCORE", 75, _H-55, "font/munro.ttf", 20)
local scoreold = display.newText(scoreCountold, 75, _H-30, "font/munro.ttf", 40)
score:setTextColor(1, 1, 1)
--/////--

--方向鍵--
local function btn_dirUp(event)
	if (#snake>1 and ydir==(Speed+su)) then
		return
	else
		xdir = 0
		if (su>0) then
			ydir = -Speed -su
		else
			ydir = -Speed
		end
	end
end

local function btn_dirDown(event)
	if (#snake>1 and ydir==-(Speed+su)) then
		return
	else
		xdir = 0
		if (su>0) then
			ydir = Speed +su
		else
			ydir = Speed
		end
	end
end

local function btn_dirLeft(event)
	if (#snake>1 and xdir==(Speed+su)) then
		return
	else
		if (su>0) then
			xdir = -Speed -su
		else
			xdir = -Speed
		end
		ydir = 0
	end
end

local function btn_dirRight(event)
	if (#snake>1 and xdir==-(Speed+su)) then
		return
	else
		if (su>0) then
			xdir = Speed +su
		else
			xdir = Speed
		end
		ydir = 0
	end
end

local btn_up = widget.newButton{
	x=display.contentCenterX,
	y=_H-110,
	defaultFile = "image/up.png",
	overFile = "image/up_1.png",
	onRelease = btn_dirUp,
}

local btn_down = widget.newButton{
	x=display.contentCenterX,
	y=_H-40,
	defaultFile = "image/down.png",
	overFile = "image/down_1.png",
	onRelease = btn_dirDown,
}

local btn_left = widget.newButton{
	x=display.contentCenterX-50,
	y=_H-75,
	defaultFile = "image/left.png",
	overFile = "image/left_1.png",
	onRelease = btn_dirLeft,
}

local btn_right = widget.newButton{
	x=display.contentCenterX+50,
	y=_H-75,
	defaultFile = "image/right.png",
	overFile = "image/right_1.png",
	onRelease = btn_dirRight,
}


local function onKeyEvent(event)

if ( event.keyName == "up" ) then
	btn_dirUp()
end
if ( event.keyName == "down" ) then
	btn_dirDown()
end
if ( event.keyName == "left" ) then
	btn_dirLeft()
end
if ( event.keyName == "right" ) then
	btn_dirRight()
end

end
Runtime:addEventListener( "key", onKeyEvent )
--/////--

--重新遊戲--
local function restart(event)
	--移除蛇和食物並初始化分數--
	for i,v in ipairs(snake) do
		v:removeSelf()
	end
	food:removeSelf()
	if(scoreCountold<scoreCount) then
		scoreCountold = scoreCount
		scoreold.text = scoreCountold
	else
		scoreCountold = scoreCountold
		scoreold.text = scoreCountold
	end
	scoreCount = 0
	score.text = scoreCount
	--/////--
	
	--初始化蛇和食物--
	xdir=0
	ydir=0
	su=0
	snake = {}
	snake[1] = display.newRect(_W/2, _H/2, Size, Size)
	snake[1]:setFillColor(0, 1, 0)
	snake[1]:translate( xdir, ydir )
	food = display.newRect(math.random(50, _W-50), math.random(20, _H-180), Size, Size)
	food:setFillColor(1, 1, 0)
	--/////--
end
local btn_restart = widget.newButton{
	x=_W-75,
	y=_H-75,
	labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } },
	label = "restart",
	font = "font/munro.ttf";
	fontSize = "40",
	onRelease = restart,
}
--/////--

--重置食物--
local function restore(event)
	food.x = math.random(50, _W-50)
	food.y = math.random(20, _H-180)
end
--/////--

--遊戲主程式--
local function game(event)
	
	local message
	local xpos = snake[1].x
	local ypos = snake[1].y
	local xnext = xpos+xdir
	local ynext = ypos+ydir
	
	--當撞到牆時重新遊戲--
	if xnext+Size/2 > Rwall.x or xnext-Size/2 < Lwall.x then
		audio.play(hit)
		restart()
	    return
	end
	if ynext+Size/2 > Floor.y or ynext-Size/2 < Top.y then
		audio.play(hit)
	    restart()
	    return
	end
	--/////--
	
	--當撞到自己時重新遊戲--
	for i,v in ipairs(snake) do
		if xnext == v.x and ynext == v.y then
			if i ~= #snake then
				audio.play(hit)
				restart()
				return
			end
		end
	end
	--/////--
	
	--當吃到食物時增長身體--
	if (xnext >= food.x-Size and xnext <= food.x+Size) and (ynext >= food.y-Size and ynext <= food.y+Size) then
		snake[#snake+1] = display.newRect(0,0, Size,Size)
		snake[#snake]:setFillColor(0, 1, 0)
		
		audio.play(eat)
		restore()
		
		scoreCount = scoreCount+1
		score.text = scoreCount
		if( scoreCount%10 == 0 ) then
			su=su+1
			audio.play(speedup)
			message = display.newText("SPEED UP", _W/2, _H-200, "font/munro.ttf", 40)
			message:setTextColor(1, 1, 1)
			local function dmessage(event)
				display.remove(message)
			end
			timer.performWithDelay(1000, dmessage)
		end
	end
	--/////--	

	--蛇移動--
	for i,v in ipairs(snake) do
		v.xold = v.x
		v.yold = v.y
		if i == 1 then 
			v:translate(xdir, ydir)
		else 
			v.x = snake[i-1].xold
			v.y = snake[i-1].yold
		end
	end
	--/////--
end
timer.performWithDelay(Delay, game, 0)
--/////--